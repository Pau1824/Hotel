import express from 'express';
import pool from '../db.js';
import { authRequired } from '../middleware/auth.js';

const router = express.Router();



//GET /api/reservas/siguiente-folio
router.get('/siguiente-folio', authRequired, async (req, res) => {
  try {
    const {rows} = await pool.query(`SELECT folio FROM reservaciones ORDER BY id_reservacion DESC LIMIT 1`);

    let nuevoFolio = 'R1000';
    if (rows.length > 0) {
      const ultimoFolio = rows[0].folio;
      const numero = parseInt(ultimoFolio.replace(/\D/g, ''), 10) + 1;
      nuevoFolio = `R${numero}`;
    }

    const nuevoFolioExt = `EXT-${nuevoFolio}`;
    res.json({ folio: nuevoFolio, folio_ext: nuevoFolioExt });
  } catch (err) {
    console.error('Error al obtener folio:', err);
    res.status(500).json({ error: 'Error al obtener folio' });
  }
});



// POST /api/reservas - Crear nueva reserva
router.post('/', authRequired, async (req, res) => {
  const r = req.body;

  // Validación rápida del payload
  if (!r.numero || !r.llegada || !r.salida || !r.folio || !r.nombre || !r.apellido) {
    return res.status(400).json({ error: 'Faltan datos requeridos (numero, llegada, salida, folio, nombre, apellido).' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Consultar tarifa de la habitación
    const {rows: hab} = await pool.query(
      'SELECT h.id_habitacion, h.tarifa_base FROM habitaciones h WHERE h.numero_habitacion = $1',
      [r.numero]
    );

    if (!hab.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Habitación no encontrada' });
    }

    const id_habitacion = hab[0].id_habitacion;
    const tarifa = Number(hab[0].tarifa_base);

    // Antes del SELECT de conflicto
    console.log('[RESERVA] id_habitacion:', id_habitacion,
            'llegada:', r.llegada, 'salida:', r.salida);

    const { rows: conflictos } = await pool.query(
      `SELECT id_reservacion, check_in, check_out, estado, folio
        FROM reservaciones
        WHERE id_habitacion = $1
          AND NOT (check_out <= $2::date OR check_in >= $3::date)
          AND estado IN ('activa','en_curso')
        LIMIT 1`,
      [id_habitacion, r.llegada, r.salida]
    );

    console.log('[RESERVA] conflictos hallados:', conflictos);

    if (conflictos.length) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'La habitación ya está reservada en ese rango de fechas.' });
    }

    const inDate  = new Date(r.llegada); inDate.setHours(0,0,0,0);
    const outDate = new Date(r.salida ); outDate.setHours(0,0,0,0);
    const noches  = Math.max(1, Math.ceil((outDate - inDate) / (1000*60*60*24)));

    const cargo_extra = Number(r.cargo_extra || 0);
    const total = tarifa * noches + cargo_extra;

    // 3. Insertar reserva
    const apellido2 = r.apellido2 ?? '';
    const { rows: ins } = await pool.query(
      `INSERT INTO reservaciones (
         id_habitacion, check_in, check_out, adultos, ninos,
         tarifa_por_noche, total_pagar, estado,
         nombre_huesped, apellido1_huesped, apellido2_hespued, -- <-- typo de tu tabla
         folio, metodo_pago
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,'activa',$8,$9,$10,$11,$12)
       RETURNING id_reservacion`,
      [
        id_habitacion,
        r.llegada, r.salida,
        r.personas || 1, 0,
        tarifa, total,
        r.nombre, r.apellido, apellido2,          // segundo apellido vacío
        r.folio, r.metodo_pago || 'efectivo'
      ]
    );

    if (!ins?.length) throw new Error('INSERT reservaciones no devolvió id_reservacion');
    const id_reservacion = ins[0].id_reservacion;

    // 4. Insertar movimiento inicial (cargo)
    await client.query(`
      INSERT INTO movimientos (id_reservacion, tipo, descripcion, cantidad, moneda)
      VALUES ($1, 'cargo', 'Renta', $2, 'MXN')
    `, [id_reservacion, total]);

    // 5. Recalcular saldo
    const { rows: tot} = await client.query(
      `SELECT 
         COALESCE(SUM(CASE WHEN tipo='cargo' THEN cantidad ELSE 0 END),0) AS debitos,
         COALESCE(SUM(CASE WHEN tipo='abono' THEN cantidad ELSE 0 END),0) AS creditos
       FROM movimientos WHERE id_reservacion=$1`,
      [id_reservacion]
    );

    const debitos  = Number(tot?.[0]?.debitos  ?? 0);
    const creditos = Number(tot?.[0]?.creditos ?? 0);
    const saldo    = creditos - debitos;

    await client.query('COMMIT');

    // 6. Actualizar saldo en reservas
    /*await pool.query(
      `UPDATE reservas SET saldo = ? WHERE id_reserva = ?`,
      [nuevoSaldo, id_reserva]
    );*/

    return res.status(201).json({
      mensaje: 'Reserva registrada correctamente',
      id_reservacion,
      noches,
      tarifa,
      total,
      totales: { debitos, creditos, saldo }
    });

    } catch (e) {
    // Log súper explícito
    await client.query('ROLLBACK');
    console.error('Error al registrar reserva >>>');
    console.error('name:', e.name);
    console.error('message:', e.message);
    console.error('code:', e.code);
    console.error('constraint:', e.constraint);
    console.error('detail:', e.detail);
    console.error('where:', e.where);
    console.error('stack:', e.stack);

    // (Opcional en desarrollo) devolver detalle:
    if (process.env.NODE_ENV !== 'production') {
      return res.status(500).json({
        error: 'Error al registrar la reserva',
        pg: process.env.NODE_ENV !== 'production'
          ? { name: e.name, message: e.message, code: e.code, constraint: e.constraint, detail: e.detail }
          : undefined
      });
    } 
  }
});



// GET /api/reservas - lista
router.get('/', authRequired, async (req, res) => {
  try {
    const scopeHotel = req.scopeHotelId;
    const sql = `
      SELECT r.id_reservacion, r.folio,
             r.nombre_huesped AS nombre, r.apellido1_huesped AS apellido,
             h.numero_habitacion AS habitacion,
             r.check_in AS llegada, r.check_out AS salida,
             r.adultos AS personas, r.tarifa_por_noche AS tarifa,
             r.total_pagar AS total, r.estado
      FROM reservaciones r
      JOIN habitaciones h ON h.id_habitacion = r.id_habitacion
      ${scopeHotel ? 'WHERE h.id_hotel = $1' : ''}
      ORDER BY r.check_in DESC, r.id_reservacion DESC`;
    const params = scopeHotel ? [scopeHotel] : [];
    const { rows } = await pool.query(sql, params);
    res.json(rows);
  } catch (error) {
    console.error('Error al obtener reservas:', error);
    res.status(500).json({ error: 'Error al obtener reservas' });
  }
});



// GET /api/reservas/:id  - Detalle de una reserva
router.put('/:id', authRequired, async (req, res) => {
  const id = req.params.id;
  const r = req.body;

  try {
    const { rows: habitacion} = await pool.query(
      'SELECT id_habitacion, tarifa_base FROM habitaciones WHERE numero_habitacion = $1',
      [r.habitacion || r.numero]
    );

    if (habitacion.length === 0) {
      return res.status(404).json({ error: 'Habitación no encontrada para actualizar' });
    }

    const id_habitacion = habitacion[0].id_habitacion;
    const tarifa = Number(habitacion[0].tarifa_base);

    // 2. Calcular noches y nuevos montos
    const llegada = new Date(r.llegada);
    const salida = new Date(r.salida);
    llegada.setHours(0, 0, 0, 0);
    salida.setHours(0, 0, 0, 0);

    const diffTime = salida - llegada;
    const noches = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
    const ingreso_renta = parseFloat(((tarifa * noches) / 1.19).toFixed(2));
    const total = (tarifa * noches);

    // 3. Actualizar reservación (nombres de columnas nuevos)
    await pool.query(`
      UPDATE reservaciones SET 
        nombre_huesped = $1, 
        apellido1_huesped = $2,  
        check_in = $3, 
        check_out = $4, 
        id_habitacion = $5,
        tarifa_por_noche = $6,
        total_pagar = $7
      WHERE id_reservacion = $8
    `, [
      r.nombre,
      r.apellido,
      r.llegada,
      r.salida,
      id_habitacion,
      tarifa,
      total,
      id
    ]);

    // 4) Upsert del cargo "Renta" en movimientos (tu nuevo esquema)
    //    No hay tabla movimientos_reserva ni campo 'concepto' texto,
    //    usamos 'descripcion'='Renta'. Si existe, lo actualizamos; si no, lo creamos.
    const { rows: cargo } = await pool.query(
      `SELECT id_movimiento
         FROM movimientos
        WHERE id_reservacion = $1
          AND tipo = 'cargo'
          AND descripcion = 'Renta'
        LIMIT 1`,
      [id]
    );

    if (cargo.length) {
      await pool.query(
        `UPDATE movimientos
            SET cantidad = $1
          WHERE id_movimiento = $2`,
        [total, cargo[0].id_movimiento]
      );
    } else {
      await pool.query(
        `INSERT INTO movimientos (id_reservacion, tipo, descripcion, cantidad, moneda, creado_por)
         VALUES ($1,'cargo','Renta',$2,'MXN',$3)`,
        [id, total, req.user?.id_usuario || null]
      );
    }

    // 5) Recalcular totales (Créditos – Débitos)
    const { rows: tot } = await pool.query(
      `SELECT
          COALESCE(SUM(CASE WHEN tipo='cargo' THEN cantidad ELSE 0 END),0) AS debitos,
          COALESCE(SUM(CASE WHEN tipo='abono' THEN cantidad ELSE 0 END),0) AS creditos
        FROM movimientos
       WHERE id_reservacion = $1`,
      [id]
    );
    const debitos  = Number(tot[0].debitos);
    const creditos = Number(tot[0].creditos);
    const saldo    = creditos - debitos;

    res.json({
      message: 'Reserva actualizada con nuevos montos',
      noches,
      total_renta: total,
      tarifa_por_noche: tarifa,
      totales: { debitos, creditos, saldo }
    });

    //res.json({ message: 'Reserva actualizada' });
  } catch (error) {
    console.error('Error actualizando reserva:', error);
    res.status(500).json({ error: error.message || 'Error actualizando reserva' });
  }
});



//GET /habitaciones/numero/:numero (buscar id por número)
router.get('/habitaciones/numero/:numero', authRequired, async (req, res) => {
  const { numero } = req.params;
  try {
    const {rows} = await pool.query('SELECT id_habitacion FROM habitaciones WHERE numero_habitacion = $1 LIMIT 1', [numero]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Habitación no encontrada' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error buscando habitación:', error);
    res.status(500).json({ error: 'Error buscando habitación' });
  }
});



// GET /api/reservas/:id/movimientos
router.get('/:id/movimientos', authRequired, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: 'ID inválido' });
  }

  try {
    const { rows } = await pool.query(
      `SELECT id_movimiento, tipo, id_concepto, descripcion, cantidad, moneda,
              metodo_pago, creado_hora
         FROM movimientos
        WHERE id_reservacion = $1
        ORDER BY creado_hora ASC, id_movimiento ASC`,
      [id]
    );

    return res.json(rows);
  } catch (e) {
    console.error('GET /reservas/:id/movimientos error:', {
      code: e.code, detail: e.detail, message: e.message
    });
    return res.status(500).json({ error: 'Error al obtener movimientos' });
  }
});



// GET /api/reservas/:id  - Detalle de una reserva
router.get('/:id', authRequired, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: 'ID inválido' });
  }

  try {
    // Datos de la reserva + info de habitación (número/tipo)
    const { rows } = await pool.query(
      `SELECT r.id_reservacion, r.folio, r.id_hotel, r.id_habitacion,
              r.nombre_huesped, r.apellido1_huesped, r.apellido2_hespued,
              r.check_in, r.check_out, r.adultos, r.ninos,
              r.tarifa_por_noche, r.total_pagar, r.estado, r.metodo_pago,
              h.numero_habitacion, h.id_tipo
         FROM reservaciones r
         JOIN habitaciones h ON h.id_habitacion = r.id_habitacion
        WHERE r.id_reservacion = $1
        LIMIT 1`,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({ error: 'Reserva no encontrada' });
    }

    const reserva = rows[0];

    // Totales del estado de cuenta (débitos = cargos, créditos = abonos)
    const { rows: tot } = await pool.query(
      `SELECT
         COALESCE(SUM(CASE WHEN tipo='cargo' THEN cantidad ELSE 0 END),0) AS debitos,
         COALESCE(SUM(CASE WHEN tipo='abono' THEN cantidad ELSE 0 END),0) AS creditos
       FROM movimientos
      WHERE id_reservacion = $1`,
      [id]
    );

    const debitos  = Number(tot[0].debitos || 0);
    const creditos = Number(tot[0].creditos || 0);
    const saldo    = creditos - debitos;

    return res.json({
      ...reserva,
      totales: { debitos, creditos, saldo }
    });
  } catch (e) {
    console.error('GET /reservas/:id error:', e);
    return res.status(500).json({ error: 'Error al obtener la reserva' });
  }
});


// POST /api/reservas/:id/movimientos
router.post('/:id/movimientos', authRequired, async (req, res) => {
  const id = Number(req.params.id);
  const { tipo, descripcion = '', cantidad, metodo_pago, codigo } = req.body;

  try {
    if (!Number.isInteger(id)) {
      return res.status(400).json({ error: 'ID inválido' });
    }
    if (!['cargo', 'abono'].includes(tipo || '')) {
      return res.status(400).json({ error: 'Tipo inválido (cargo|abono)' });
    }
    const monto = Number(cantidad);
    if (!Number.isFinite(monto) || monto <= 0) {
      return res.status(400).json({ error: 'Cantidad inválida' });
    }
    // Para abonos exigimos método de pago
    if (tipo === 'abono' && !['efectivo', 'tarjeta'].includes((metodo_pago || '').toLowerCase())) {
      return res.status(400).json({ error: 'Método de pago requerido para abonos' });
    }

    // Si te mandan un "codigo" (por ejemplo 1000/2000/2001),
    // lo traducimos a id_concepto. Si no, lo dejamos en null.
    let id_concepto = null;
    if (codigo != null) {
      const { rows: c } = await pool.query(
        'SELECT id_concepto FROM concepto_codigo WHERE codigo = $1 LIMIT 1',
        [String(codigo)]
      );
      if (c.length === 0) {
        return res.status(400).json({ error: `Código de concepto desconocido: ${codigo}` });
      }
      id_concepto = c[0].id_concepto;
    }

    // Inserción usando columnas reales de tu tabla
    const { rows: ins } = await pool.query(
      `INSERT INTO movimientos
         (id_reservacion, id_concepto, tipo, descripcion, cantidad, moneda, metodo_pago, creado_por)
       VALUES ($1, $2, $3, $4, $5, 'MXN', $6, $7)
       RETURNING id_movimiento`,
      [id, id_concepto, tipo, descripcion, monto, metodo_pago || null, req.user?.id_usuario || null]
    );

    // Totales (débitos/cargos y créditos/abonos)
    const { rows: tot } = await pool.query(
      `SELECT
         COALESCE(SUM(CASE WHEN tipo='cargo' THEN cantidad ELSE 0 END),0) AS debitos,
         COALESCE(SUM(CASE WHEN tipo='abono' THEN cantidad ELSE 0 END),0) AS creditos
       FROM movimientos
       WHERE id_reservacion = $1`,
      [id]
    );

    const debitos  = Number(tot[0].debitos);
    const creditos = Number(tot[0].creditos);
    const saldo    = creditos - debitos;

    return res.status(201).json({
      id_movimiento: ins[0].id_movimiento,
      totales: { debitos, creditos, saldo }
    });
  } catch (e) {
    console.error('POST /reservas/:id/movimientos', e.code, e.message, e.detail, e.constraint);
    return res.status(500).json({ error: 'Error al registrar movimiento' });
  }
});




// PUT /api/reservas/:id/checkin
router.put('/:id/checkin', authRequired, async (req, res) => {
  const { id } = req.params;

  try {
    const {reservas} = await pool.query('SELECT * FROM reservaciones WHERE id_reservacion = $1', [req.params.id]);

    if (reservas.length === 0) {
      return res.status(404).json({ error: 'Reserva no encontrada' });
    }

    const reserva = reservas[0];

    if (reserva.estado !== 'Reservada') {
      return res.status(400).json({ error: 'La reserva no está en estado Reservada' });
    }

    // Cambiar estado de la reserva
    await pool.query('UPDATE reservaciones SET estado = \"En curso\" WHERE id_reserva = $1', [req.params.id]);

    // Cambiar estado de la habitación
    await pool.query('UPDATE habitaciones SET estado = \"Ocupada\" WHERE id_habitacion = $1', [reserva.id_habitacion]);

    res.json({ mensaje: 'Check-in realizado con éxito' });
  } catch (error) {
    console.error('Error al hacer check-in:', error);
    res.status(500).json({ error: 'Error al realizar el check-in' });
  }
});



// PUT /api/reservas/:id/checkout
router.put('/:id/checkout', authRequired, async (req, res) => {
  const { id } = req.params;

  try {
    const {reservas} = await pool.query('SELECT * FROM reservaciones WHERE id_reserva = $1', [req.params.id]);

    if (reservas.length === 0) {
      return res.status(404).json({ error: 'Reserva no encontrada' });
    }

    const reserva = reservas[0];

    // 1. Validar que esté en curso
    if (reserva.estado !== 'En curso') {
      return res.status(400).json({ error: 'Solo se puede hacer check-out a reservas en curso' });
    }

    // 2. Validar que el saldo sea exactamente 0
    if (parseFloat(reserva.saldo) !== 0) {
      return res.status(400).json({ error: 'No se puede hacer check-out: el saldo no es 0.00' });
    }

    // 3. Validar que la fecha actual esté dentro del rango (>= llegada)
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const outDate = new Date(reserva.check_out);
    outDate.setHours(0, 0, 0, 0);

    if (hoy < llegada) {
      return res.status(400).json({ error: 'No se puede hacer check-out antes de la fecha de llegada' });
    }

    // Cambiar estado de la reserva
    await pool.query('UPDATE reservacion SET estado = \"Finalizada\" WHERE id_reservacion = ?', [id]);

    // Cambiar estado de la habitación
    await pool.query('UPDATE habitaciones SET estado = \"Disponible\" WHERE id_habitacion = ?', [reserva.id_habitacion]);

    res.json({ mensaje: 'Check-out realizado con éxito' });
  } catch (error) {
    console.error('Error al hacer check-out:', error);
    res.status(500).json({ error: 'Error al realizar el check-out' });
  }
});



// POST /api/reservas/:id/checkin
router.post('/:id/checkin', authRequired, async (req, res) => {
  const id = Number(req.params.id);
  let client;

  try {
    client = await pool.connect();    // <<--- OBTÉN UN CLIENTE
    await client.query('BEGIN');

    // 1) Carga la reserva
    const { rows: rsv } = await client.query(
      `SELECT r.id_reservacion, r.id_habitacion, r.estado, r.check_in::date AS check_in
         FROM reservaciones r
        WHERE r.id_reservacion = $1
        FOR UPDATE`,                   // bloquéala durante el check-in
      [id]
    );
    if (!rsv.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Reserva no encontrada' });
    }

    const reserva = rsv[0];

    // 2) Validaciones básicas (ajusta a tu lógica de negocio)
    const hoy = new Date(); hoy.setHours(0,0,0,0);
    const checkIn = new Date(reserva.check_in); checkIn.setHours(0,0,0,0);

    if (reserva.estado !== 'activa') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: `No se puede hacer check-in si el estado es '${reserva.estado}'` });
    }
    // si quieres exigir misma fecha:
    // if (checkIn.getTime() !== hoy.getTime()) { ... }

    // 3) Marcar habitación ocupada y reserva en_curso
    await client.query(
      `UPDATE habitaciones
          SET estado = 'ocupada'
        WHERE id_habitacion = $1`,
      [reserva.id_habitacion]
    );

    await client.query(
      `UPDATE reservaciones
          SET estado = 'en_curso'
        WHERE id_reservacion = $1`,
      [id]
    );

    // 4) (Opcional) registra un movimiento informativo del check-in
    await client.query(
      `INSERT INTO movimientos
         (id_reservacion, tipo, descripcion, cantidad, moneda, creado_por)
       VALUES ($1,'cargo','Apertura de cuenta (check-in)',0,'MXN',$2)`,
      [id, req.user?.id_usuario || null]
    );

    await client.query('COMMIT');
    res.json({ mensaje: 'Check-in realizado', id_reservacion: id });

  } catch (e) {
    if (client) { try { await client.query('ROLLBACK'); } catch (_) {} }
    console.error('POST /reservas/:id/checkin', e.code, e.message, e.detail);
    res.status(500).json({ error: 'Error al procesar check-in' });
  } finally {
    if (client) client.release();     // <<--- SUÉLTALO SIEMPRE
  }
});




// Check-Out
router.put('/:id_reserva/checkout', (req, res) => {
  const id_reserva = req.params.id_reserva;

  const sql = `
    UPDATE reservacion r
    JOIN habitaciones h ON r.id_habitacion = h.id_habitacion
    SET r.estado = 'Finalizada', h.estado = 'Disponible'
    WHERE r.id_reservacion = ? AND r.estado = 'En curso' AND CURRENT_DATE >= r.salida
  `;

  conn.query(sql, [id_reserva], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.affectedRows === 0) {
      return res.status(400).json({ message: 'No se puede hacer Check-Out. Verifica el estado o la fecha.' });
    }
    res.json({ message: 'Check-Out exitoso' });
  });
});



// POST /api/reservas/:id/checkout  -> cierra una reserva si no hay saldo pendiente
router.post('/:id/checkout', authRequired, async (req, res) => {
  const id = Number(req.params.id);

  try {
    // 1) Verificar que exista la reserva
    const { rows: rsv } = await pool.query(
      `SELECT id_reservacion, estado
         FROM reservaciones
        WHERE id_reservacion = $1
        LIMIT 1`,
      [id]
    );
    if (!rsv.length) return res.status(404).json({ error: 'Reserva no existe' });

    // 2) Totales en movimientos (tu tabla real)
    const { rows: tot } = await pool.query(
      `SELECT
          COALESCE(SUM(CASE WHEN tipo='cargo' THEN cantidad ELSE 0 END),0) AS debitos,
          COALESCE(SUM(CASE WHEN tipo='abono' THEN cantidad ELSE 0 END),0) AS creditos
         FROM movimientos
        WHERE id_reservacion = $1`,
      [id]
    );
    const debitos  = Number(tot[0].debitos);
    const creditos = Number(tot[0].creditos);
    const saldo    = creditos - debitos;   // saldo <= 0 para permitir checkout

    if (saldo < 0) {
      return res.status(409).json({
        error: 'Saldo pendiente',
        detalle: { debitos, creditos, saldo }
      });
    }

    // 3) Cambiar estado a 'finalizada' (usa tus valores válidos)
    await pool.query(
      `UPDATE reservaciones
          SET estado = 'finalizada'
        WHERE id_reservacion = $1`,
      [id]
    );

    // 4) (Opcional) registrar un movimiento “Check-out” informativo
    await pool.query(
      `INSERT INTO movimientos
         (id_reservacion, tipo, descripcion, cantidad, moneda, metodo_pago, creado_por)
       VALUES ($1, 'cargo', 'Cierre de cuenta (checkout)', 0, 'MXN', NULL, $2)`,
      [id, req.user?.id_usuario || null]
    );

    return res.json({
      mensaje: 'Checkout realizado',
      totales: { debitos, creditos, saldo }
    });
  } catch (e) {
    console.error('POST /reservas/:id/checkout', e.code, e.message, e.detail);
    return res.status(500).json({ error: 'Error al procesar checkout' });
  }
});



// POST /api/reservas/:id/cancelar
router.post('/:id/cancelar', authRequired, async (req, res) => {
  const id = Number(req.params.id);
  const motivo = (req.body?.motivo ?? '').toString().slice(0, 250) || 'Cancelación';

  try {
    // 1) Trae la reserva
    const { rows: rsv } = await pool.query(
      `SELECT id_reservacion, estado, id_habitacion
         FROM reservaciones
        WHERE id_reservacion = $1`,
      [id]
    );
    if (!rsv.length) return res.status(404).json({ error: 'Reserva no encontrada' });

    const estado = rsv[0].estado;
    if (estado === 'en_curso' || estado === 'finalizada') {
      return res.status(409).json({ error: 'No se puede cancelar una reserva en curso o finalizada' });
    }

    // 2) Calcula totales actuales (para reportar)
    const { rows: tot } = await pool.query(
      `SELECT
         COALESCE(SUM(CASE WHEN tipo='cargo' THEN cantidad ELSE 0 END),0) AS debitos,
         COALESCE(SUM(CASE WHEN tipo='abono' THEN cantidad ELSE 0 END),0) AS creditos
       FROM movimientos
       WHERE id_reservacion = $1`,
      [id]
    );
    const debitos  = Number(tot[0].debitos);
    const creditos = Number(tot[0].creditos);
    const saldo_cliente   = creditos - debitos; // saldo a favor del cliente (+) o en contra (-)
    const saldo_pendiente = debitos - creditos; // lo que debe el cliente

    await pool.query('BEGIN');

    // 3) Marca la reserva cancelada
    await pool.query(
      `UPDATE reservaciones
          SET estado = 'cancelada'
        WHERE id_reservacion = $1`,
      [id]
    );

    // 4) (Opcional) registra un movimiento informativo
    await pool.query(
      `INSERT INTO movimientos (id_reservacion, tipo, descripcion, cantidad, moneda, creado_por)
       VALUES ($1, 'cargo', $2, 0, 'MXN', $3)`,
      [id, `Cancelación: ${motivo}`, req.user?.id_usuario ?? null]
    );

    await pool.query('COMMIT');

    res.json({
      mensaje: 'Reserva cancelada',
      totales: { debitos, creditos, saldo_cliente, saldo_pendiente }
    });
  } catch (e) {
    await pool.query('ROLLBACK');
    console.error('POST /reservas/:id/cancelar', e.code, e.message, e.detail);
    res.status(500).json({ error: 'Error al cancelar la reserva' });
  }
});

export default router;
